﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lavirint
{
    class MinMaxSearch
    {
        public State search(State pocetnoStanje, int dubina=5, bool agentMaksimizuje=false)
        {
            // TODO Dodatno: Implementirati MinMax pretragu sa protivnikom
            return null;
        }
    }
}
