﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace PretrageOsnovno
{
    class DepthFirstSearch
    {
        public State Search(string startNodeName, string endNodeName)
        {
            // TODO 3: implementirati algoritam prvi u dubinu            
            return null;
        }
    }
}
